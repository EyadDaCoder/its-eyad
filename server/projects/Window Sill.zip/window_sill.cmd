@ECHO OFF
ECHO Window Sill autobot
ECHO Configuration in source/sequence.json
SET /P confirmation=Start the bot? (y/N) - 

IF /I "%confirmation%"=="y" (
    ECHO Running bot...
    python source/wrapper.py
    ECHO Finished!
    PAUSE
) ELSE (
    ECHO Cancelling!
)