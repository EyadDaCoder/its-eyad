import pyautogui
from time import sleep as delay
import pynput
from json import load
import sys



class window_sill:

    def __init__(self):
        with open("source\\sequence.json", "r") as f:
            data = load(f)
        self.config = data
        self.variables = self.config["variables"]
        pyautogui.FAILSAFE = self.config["failsafe"]
        self.repeat_action = [False, None]

    def resolve(self, parameter):
        if not isinstance(parameter, str):
            return parameter # Not a variable - not a string
        else:
            if parameter[0] != "@":
                return parameter # Not a variable - no declaration
            else:
                try:
                    return self.variables[parameter[1:]]
                except KeyError:
                    return parameter # Not a variable - does not exist

    def interpreter(self):
        for i in range(self.config["repeat"]): # Repeat for the amount of times specified in sequence.json
            for action in self.config["sequence"]:
                

                if "click" in action: # Checking if the current action is to "click" (click the right or left mouse button)
                    if self.repeat_action[0] == True: # If there is a repeat statement that has been opened
                         for i in range(self.repeat_action[1]):
                            mouse_button = self.resolve(action["click"][0])
                            hold_duration = self.resolve(action["click"][1])
                            pyautogui.mouseDown(button = mouse_button)
                            delay(hold_duration)
                            pyautogui.mouseUp()
                            print(f"CLICKED: {mouse_button}, {hold_duration}")
                    else:
                            mouse_button = self.resolve(action["click"][0])
                            hold_duration = self.resolve(action["click"][1])
                            pyautogui.mouseDown(button = mouse_button)
                            delay(hold_duration)
                            pyautogui.mouseUp()
                            print(f"CLICKED: {mouse_button}, {hold_duration}")


                elif "move" in action: # Checking if the current action is to "move" (move the cursor to a point in the screen)
                    coordinates = [self.resolve(action["move"][0]), self.resolve(action["move"][1])]
                    length = self.resolve(action["move"][2])
                    pyautogui.moveTo(x=coordinates[0], y=coordinates[1], duration=length)
                    print(f"MOVED: {coordinates}, {length}")

                elif "type" in action: # Checking if the current action is to "type" (press a specific letter on the keyboard)
                    if self.repeat_action[0] == True:
                        for i in range(self.repeat_action[1]):
                            key = self.resolve(action["type"][0])
                            length = self.resolve(action["type"][1])
                            pyautogui.keyDown(key)
                            delay(length)
                            pyautogui.keyUp(key)
                            print(f"TYPED: {key}, {length}")
                    else:
                        key = self.resolve(action["type"][0])
                        length = self.resolve(action["type"][1])
                        pyautogui.keyDown(key)
                        delay(length)
                        pyautogui.keyUp(key)
                        print(f"TYPED: {key}, {length}")
                    

                elif "delay" in action:
                    delay(action["delay"])

                elif "start-repeat" in action:
                    self.repeat_action[0] = True
                    self.repeat_action[1] = self.resolve(action["start-repeat"])
                    
                elif "end-repeat" in action:
                    self.repeat_action[0] = False
                    self.repeat_action[1] = None

                elif "variable" in action:
                    self.variables[action["variable"][0]] = action["variable"][1]